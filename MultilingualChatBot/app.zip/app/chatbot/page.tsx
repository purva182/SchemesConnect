import React, { useState, useRef, useEffect } from "react";
import { Send, Moon, Sun } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function ChatApp() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>("");
  const [showQuickReplies, setShowQuickReplies] = useState<boolean>(true);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const quickReplies: string[] = [
    "Eligibility criteria for Pradhan Mantri Awaas...",
    "Application process of Kisan Credit Scheme",
    "Schemes for students?",
  ];

  const getAssistantResponse = (userMessage: string): string => {
    if (userMessage.toLowerCase().includes("pradhan mantri awa")) {
      return "Pradhan Mantri Awaas Yojana provides affordable housing. Eligibility depends on income and location.";
    } else if (userMessage.toLowerCase().includes("kisan credit scheme")) {
      return "Kisan Credit Scheme provides short-term loans to farmers. Applications can be made via banks.";
    } else if (userMessage.toLowerCase().includes("students")) {
      return "There are several schemes for students like scholarships, internships, and skill development programs.";
    } else {
      return "Sorry, I don't have information on that. Please try another query.";
    }
  };

  const handleSend = (): void => {
    if (!input.trim()) return;

    const userMsg: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setShowQuickReplies(false);

    setIsTyping(true);
    setTimeout(() => {
      const assistantMsg: Message = {
        role: "assistant",
        content: getAssistantResponse(userMsg.content),
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1000);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  return (
    <div
      className={`min-h-screen flex justify-center items-center p-6 transition-colors duration-500 ${
        darkMode
          ? "bg-gray-900"
          : "bg-gradient-to-br from-blue-100 via-blue-50 to-white"
      }`}
    >
      <div className="w-full max-w-3xl flex flex-col space-y-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1
              className={`text-4xl font-extrabold tracking-wide ${
                darkMode ? "text-blue-400" : "text-blue-700"
              }`}
            >
              SchemesConnect
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              One-stop portal for government schemes & citizen services
            </p>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition"
          >
            {darkMode ? (
              <Sun className="w-5 h-5 text-yellow-400" />
            ) : (
              <Moon className="w-5 h-5 text-gray-600" />
            )}
          </button>
        </div>

        {/* Messages */}
        <div className="flex flex-col space-y-3 overflow-y-auto max-h-[400px] p-2 rounded-xl">
          <AnimatePresence>
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`p-4 rounded-2xl max-w-[80%] break-words shadow ${
                  msg.role === "user"
                    ? "ml-auto bg-gradient-to-r from-blue-500 to-blue-400 text-white"
                    : darkMode
                    ? "bg-gray-700 text-gray-200"
                    : "bg-gray-100 text-gray-800"
                }`}
              >
                {msg.content}
              </motion.div>
            ))}
            {isTyping && (
              <motion.div
                key="typing"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-2xl max-w-[30%] bg-gray-200 flex items-center space-x-2"
              >
                <span className="dot animate-bounce bg-gray-500 w-2 h-2 rounded-full"></span>
                <span className="dot animate-bounce bg-gray-500 w-2 h-2 rounded-full delay-150"></span>
                <span className="dot animate-bounce bg-gray-500 w-2 h-2 rounded-full delay-300"></span>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>

        {/* Quick reply buttons */}
        {showQuickReplies && (
          <div className="flex flex-wrap gap-3 mt-2">
            {quickReplies.map((q, i) => (
              <motion.button
                key={i}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-blue-500 to-blue-400 text-white px-5 py-2 rounded-full font-medium shadow hover:shadow-lg transition"
                onClick={() => setInput(q)}
              >
                {q}
              </motion.button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="flex items-center mt-4 bg-white rounded-full shadow-md overflow-hidden border border-gray-200">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-5 py-3 focus:outline-none text-gray-700 bg-white placeholder-gray-400"
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
          <button
            onClick={handleSend}
            className="px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        {/* Disclaimer */}
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 text-center">
          *SchemesConnect assistant may make mistakes. Always verify important
          information.
        </p>
      </div>

      {/* Typing animation styles */}
      <style>{`
        .dot {
          animation: bounce 1.2s infinite;
        }
        .dot.delay-150 { animation-delay: 0.15s; }
        .dot.delay-300 { animation-delay: 0.3s; }
        @keyframes bounce {
          0%, 80%, 100% { transform: scale(0); }
          40% { transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
